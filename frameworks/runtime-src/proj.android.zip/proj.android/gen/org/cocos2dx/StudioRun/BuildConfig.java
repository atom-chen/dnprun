/** Automatically generated file. DO NOT MODIFY */
package org.cocos2dx.StudioRun;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}